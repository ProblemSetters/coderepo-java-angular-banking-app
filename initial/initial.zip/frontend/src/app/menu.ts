export const menuList = [
	{
		name: "Dashboard",
		url: "",
	},
	{
		name: "Beneficiary",
		url: "beneficiary",
	},
	{
		name: "Send Money",
		url: "send-money",
	},
    {
		name: "Transaction",
		url: "transaction",
	},
    {
		name: "Cards",
		url: "cards",
	},	
	{
		name: "Reward Points",
		url: "reward-points",
	},
	{
		name: "Apply Loan",
		url: "apply-loan",
	},
];