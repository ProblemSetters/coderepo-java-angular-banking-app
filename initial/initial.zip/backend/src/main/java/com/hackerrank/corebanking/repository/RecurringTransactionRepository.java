public class RecurringTransactionRepository {
    
}
