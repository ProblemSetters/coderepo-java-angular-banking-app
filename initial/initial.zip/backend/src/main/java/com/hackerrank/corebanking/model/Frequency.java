public class Frequency {
    
}
