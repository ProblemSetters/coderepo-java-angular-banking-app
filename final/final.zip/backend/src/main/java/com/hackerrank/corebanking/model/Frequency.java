package com.hackerrank.corebanking.model;

public enum Frequency {
    DAILY,
    WEEKLY,
    MONTHLY
}
